#!/bin/bash
killall pangolin_desktop&&startx
