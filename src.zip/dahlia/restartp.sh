killall pangolin_desktop&&startx
